# BiLSTM Sign Classifier

Train on real data with `python train.py --data path/to/folder_dataset --output outputs`.
Use `python train.py --synthetic --epochs 20 --output outputs` for an end-to-end smoke test.

Dataset folders must be `dataset/<label>/<sample>.npy` (or JSON), where each file is a 2-D `[frames, features]` landmark coordinate array. An index CSV/Parquet may instead contain `label` and `sequence_path` columns. Configure landmark layout in `PipelineConfig` before training; the default expects one 21-point xyz hand (63 features).
