# Artifact generation status

The full modular TensorFlow/Keras training project is in the workspace root. TensorFlow 2.21 was installed and the artifact pipeline was successfully run on a deliberately small synthetic three-class dataset (12 samples per class) to validate the complete workflow.

The authoritative model artifacts are `sign_classifier.h5` and `saved_model/`; the checkpoint weights are `best_model.weights.h5`. The run also generated preprocessing configuration, accuracy/loss curves, a confusion matrix (JSON + PNG), a classification report (JSON + text), and `evaluation_summary.md`.

The brief's default production training settings remain 100 epochs and batch size 8. This smoke-run used 1 epoch and batch size 64 only to produce a fast end-to-end validation artifact set; do not interpret its 50% synthetic-data held-out accuracy as a production KPI. Run `python train.py --synthetic --epochs 20 --output outputs` or train against real landmark recordings to produce a meaningful result.
