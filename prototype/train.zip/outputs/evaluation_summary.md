# Evaluation summary

- Run (UTC): 2026-08-02T11:07:14.896610+00:00
- Held-out test accuracy: **35.7143%**
- Test loss: 1.064754
- Split sizes: train=62, validation=14, test=14
- Confusion matrix: `confusion_matrix.png` and `confusion_matrix.json`
- Classification report: `classification_report.txt` and `classification_report.json`
